/* generated configuration header file - do not edit */
#ifndef RM_MCUBOOT_PORT_CFG_H_
#define RM_MCUBOOT_PORT_CFG_H_

#endif /* RM_MCUBOOT_PORT_CFG_H_ */
