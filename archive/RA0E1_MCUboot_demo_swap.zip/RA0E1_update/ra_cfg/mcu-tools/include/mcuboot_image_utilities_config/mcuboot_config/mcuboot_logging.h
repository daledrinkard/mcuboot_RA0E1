/* generated configuration header file - do not edit */
#ifndef MCUBOOT_LOGGING_H_
#define MCUBOOT_LOGGING_H_
#ifndef MCUBOOT_IMAGE_UTILITIES_MCUBOOT_LOGGING_H_
#define MCUBOOT_IMAGE_UTILITIES_MCUBOOT_LOGGING_H_
#undef MCUBOOT_LOGGING_H_
#include "sysflash/sysflash.h"
#endif
#endif /* MCUBOOT_LOGGING_H_ */
