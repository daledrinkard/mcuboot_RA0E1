/* generated configuration header file - do not edit */
#ifndef MCUBOOT_CONFIG_H_
#define MCUBOOT_CONFIG_H_
#ifndef MCUBOOT_IMAGE_UTILITIES_MCUBOOT_CONFIG_H_
#define MCUBOOT_IMAGE_UTILITIES_MCUBOOT_CONFIG_H_
#undef MCUBOOT_CONFIG_H_
#include "sysflash/sysflash.h"
#endif
#endif /* MCUBOOT_CONFIG_H_ */
